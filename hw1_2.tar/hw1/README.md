# hw1
hw1 for PCC CS161

Build steps: 
  1. Navigate to this project in the terminal
  2. Enter "make"
  3. Enter "./HW1"
